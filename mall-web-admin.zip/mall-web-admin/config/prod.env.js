'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"http://39.106.212.32:8085"'
}
