<template> 
    <smsDiypageTemplateCategory-detail :is-edit='true'>
</smsDiypageTemplateCategory-detail>
</template>
<script>
    import SmsDiypageTemplateCategoryDetail from './components/detail'

    export default {
        name: 'updateSmsDiypageTemplateCategory',
        components: {SmsDiypageTemplateCategoryDetail}
    }
</script>
<style>
</style>


