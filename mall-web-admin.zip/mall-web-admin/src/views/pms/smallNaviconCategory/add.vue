<template> 
  <smallNaviconCategory-detail :is-edit='false'></smallNaviconCategory-detail>
</template>
<script>
  import SmallNaviconCategoryDetail from './components/SmallNaviconCategoryDetail'
  export default {
    name: 'addSmallNaviconCategory',
    components: { SmallNaviconCategoryDetail }
  }
</script>
<style>
</style>


