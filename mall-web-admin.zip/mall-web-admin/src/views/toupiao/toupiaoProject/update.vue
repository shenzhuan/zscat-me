<template> 
    <toupiaoProject-detail :is-edit='true'>
</toupiaoProject-detail>
</template>
<script>
    import ToupiaoProjectDetail from './components/detail'

    export default {
        name: 'updateToupiaoProject',
        components: {ToupiaoProjectDetail}
    }
</script>
<style>
</style>


