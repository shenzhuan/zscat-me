<template> 
    <toupiaoProject-detail :is-edit='false'>
</toupiaoProject-detail>
</template>
<script>
    import ToupiaoProjectDetail from './components/detail'

    export default {
        name: 'addToupiaoProject',
        components: {ToupiaoProjectDetail}
    }
</script>
<style>
</style>


