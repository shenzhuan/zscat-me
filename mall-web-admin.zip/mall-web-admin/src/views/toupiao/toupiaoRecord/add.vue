<template> 
    <toupiaoRecord-detail :is-edit='false'>
</toupiaoRecord-detail>
</template>
<script>
    import ToupiaoRecordDetail from './components/detail'

    export default {
        name: 'addToupiaoRecord',
        components: {ToupiaoRecordDetail}
    }
</script>
<style>
</style>


