<template> 
    <toupiaoRecord-detail :is-edit='true'>
</toupiaoRecord-detail>
</template>
<script>
    import ToupiaoRecordDetail from './components/detail'

    export default {
        name: 'updateToupiaoRecord',
        components: {ToupiaoRecordDetail}
    }
</script>
<style>
</style>


