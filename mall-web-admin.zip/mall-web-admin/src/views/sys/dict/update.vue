<template> 
    <dict-detail :is-edit='true'>
</dict-detail>
</template>
<script>
    import DictDetail from './components/DictDetail'

    export default {
        name: 'updateDict',
        components: {DictDetail}
    }
</script>
<style>
</style>


