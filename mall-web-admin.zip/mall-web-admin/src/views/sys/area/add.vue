<template> 
  <area-detail :is-edit='false'></area-detail>
</template>
<script>
  import AreaDetail from './components/AreaDetail'
  export default {
    name: 'addArea',
    components: { AreaDetail }
  }
</script>
<style>
</style>


