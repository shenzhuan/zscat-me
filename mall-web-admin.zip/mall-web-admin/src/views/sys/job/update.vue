<template> 
    <job-detail :is-edit='true'>
</job-detail>
</template>
<script>
    import JobDetail from './components/JobDetail'

    export default {
        name: 'updateJob',
        components: {JobDetail}
    }
</script>
<style>
</style>


