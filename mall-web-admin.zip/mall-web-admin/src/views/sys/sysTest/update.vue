<template> 
    <sysTest-detail :is-edit='true'>
</sysTest-detail>
</template>
<script>
    import SysTestDetail from './components/detail'

    export default {
        name: 'updateSysTest',
        components: {SysTestDetail}
    }
</script>
<style>
</style>


