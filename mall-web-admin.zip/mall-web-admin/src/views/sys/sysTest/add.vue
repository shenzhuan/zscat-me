<template> 
    <sysTest-detail :is-edit='false'>
</sysTest-detail>
</template>
<script>
    import SysTestDetail from './components/detail'

    export default {
        name: 'addSysTest',
        components: {SysTestDetail}
    }
</script>
<style>
</style>


