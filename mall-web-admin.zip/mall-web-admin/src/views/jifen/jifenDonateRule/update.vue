<template> 
    <jifenDonateRule-detail :is-edit='true'>
</jifenDonateRule-detail>
</template>
<script>
    import JifenDonateRuleDetail from './components/detail'

    export default {
        name: 'updateJifenDonateRule',
        components: {JifenDonateRuleDetail}
    }
</script>
<style>
</style>


