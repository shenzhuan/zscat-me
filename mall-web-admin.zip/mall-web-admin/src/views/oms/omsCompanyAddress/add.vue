<template> 
    <omsCompanyAddress-detail :is-edit='false'>
</omsCompanyAddress-detail>
</template>
<script>
    import OmsCompanyAddressDetail from './components/detail'

    export default {
        name: 'addOmsCompanyAddress',
        components: {OmsCompanyAddressDetail}
    }
</script>
<style>
</style>


