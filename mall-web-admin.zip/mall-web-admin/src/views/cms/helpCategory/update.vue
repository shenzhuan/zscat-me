<template> 
  <helpCategory-detail :is-edit='true'></helpCategory-detail>
</template>
<script>
  import HelpCategoryDetail from './components/HelpCategoryDetail'
  export default {
    name: 'updateHelpCategory',
    components: { HelpCategoryDetail }
  }
</script>
<style>
</style>


