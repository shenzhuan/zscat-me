<template> 
  <topic-detail :is-edit='true'></topic-detail>
</template>
<script>
  import TopicDetail from './components/TopicDetail'
  export default {
    name: 'updateTopic',
    components: { TopicDetail }
  }
</script>
<style>
</style>


